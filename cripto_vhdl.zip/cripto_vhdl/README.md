# Cifrador didático de 10 bits

Projeto em VHDL-2008. O núcleo integra a FSM de 16 estados e o datapath.
Criptografia.vhd preserva o nome da entidade temp1 do esqueleto inicial.

## Interface de temp1

- clk: clock único. reset: reset síncrono ativo em 1; também cancela o desafio.
- confirmar: pulso de um ciclo, condicionado antes de entrar no núcleo.
- modo_decifrar: 0 cria desafio, 1 tenta decifrar. Só é lido no INIT.
- switches: dados de 10 bits. Na cifragem, confirme primeiro V e depois K.
- operacao: 00 troca vizinhos; 01 gira três bits (esquerda na cifra, direita na decifra); 10 XOR; 11 ignora.
- valor_saida: valor de trabalho ou cifrado no menu, quando válido.
- estado: número do estado (0 a 15).
- led_acerto: resultado registrado em S14 e mantido em S15.

Execute três operações em cada fase. Repetições são permitidas. Na decifragem,
cada seleção de XOR exige um segundo pulso para carregar o palpite pelas
switches. Em S15, confirmar reinicia a tentativa a partir do cifrado preservado.
Para criar outro desafio a partir de S15, use reset e escolha cifrar no INIT.

O clock_div oferece um pulso periódico opcional. Ele não filtra botões e não é
usado como clock do núcleo. A integração física da placa (pinos, sincronização,
debounce e decodificação de sete segmentos) fica fora de temp1. Para ligar os
três displays, divida valor_saida em 00 & bits 9:8, bits 7:4 e bits 3:0.

## Simulação

Execute sh simular.sh. Abra sim/criptografia.vcd no GTKWave.
O testbench usa processos e wait for, sem assert, report ou procedures.
Confira os instantes anotados no testbench: rejeição de decifrar sem desafio,
três XOR consecutivos, tentativa errada, nova tentativa e LED aceso.

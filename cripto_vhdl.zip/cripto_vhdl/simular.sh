#!/bin/sh
set -eu
cd "$(dirname "$0")"
mkdir -p sim
cd sim
ghdl -a --std=08 ../registrador.vhd ../comparador.vhd ../incrementador.vhd ../roller.vhd ../xor.vhd ../permuter.vhd ../clock_div.vhd ../datapath.vhd ../controller.vhd ../Criptografia.vhd ../tb_criptografia.vhd
ghdl -e --std=08 tb_criptografia
ghdl -r --std=08 tb_criptografia --vcd=criptografia.vcd

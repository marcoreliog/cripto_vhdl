library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
-- Núcleo: confirmar deve ser um pulso de um ciclo, já condicionado.
entity temp1 is
 port(clk, reset, confirmar, modo_decifrar : in std_logic;
      switches : in std_logic_vector(9 downto 0);
      operacao : in std_logic_vector(1 downto 0);
      valor_saida : out std_logic_vector(9 downto 0);
      led_acerto : out std_logic;
      estado : out std_logic_vector(3 downto 0));
end entity;
architecture rtl of temp1 is
 signal ld_v, ld_k, ld_x, ld_c, rot_mode, clr_n, inc_n, ld_acerto, clr_acerto, set_valido, clr_valido, sel_saida, fim_camadas, cifrado_valido : std_logic;
 signal sel_x : std_logic_vector(2 downto 0);
begin
 uc: entity work.controller port map(clk, reset, confirmar, modo_decifrar,
       fim_camadas, cifrado_valido, operacao, ld_v, ld_k, ld_x, ld_c, rot_mode, clr_n, inc_n, ld_acerto, clr_acerto, set_valido, clr_valido, sel_saida, sel_x, estado);
 dp: entity work.datapath port map(clk, reset, switches,
       ld_v, ld_k, ld_x, ld_c, rot_mode, clr_n, inc_n, ld_acerto, clr_acerto, set_valido, clr_valido, sel_saida, sel_x, fim_camadas, cifrado_valido, led_acerto, valor_saida);
end architecture;

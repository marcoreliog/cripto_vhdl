library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity tb_criptografia is end entity;
architecture sim of tb_criptografia is
 signal clk, reset, confirmar, modo_decifrar, led_acerto : std_logic := '0';
 signal switches, valor_saida : std_logic_vector(9 downto 0) := (others => '0');
 signal operacao : std_logic_vector(1 downto 0) := "00";
 signal estado : std_logic_vector(3 downto 0);
begin
 dut: entity work.temp1 port map(clk, reset, confirmar, modo_decifrar,
        switches, operacao, valor_saida, led_acerto, estado);
 process
 begin
  while now < 1200 ns loop
   clk <= '0'; wait for 5 ns;
   clk <= '1'; wait for 5 ns;
  end loop;
  wait;
 end process;
 process
 begin
  reset <= '1'; wait for 10 ns; reset <= '0';
  modo_decifrar <= '1';
  confirmar <= '1'; wait for 10 ns;
  confirmar <= '0'; wait for 30 ns;
  -- 50 ns: D sem cifrado mantém INIT.
  modo_decifrar <= '0';
  confirmar <= '1'; wait for 10 ns;
  confirmar <= '0'; wait for 30 ns;
  switches <= std_logic_vector(to_unsigned(1, 10));
  confirmar <= '1'; wait for 10 ns;
  confirmar <= '0'; wait for 30 ns;
  switches <= std_logic_vector(to_unsigned(3, 10));
  confirmar <= '1'; wait for 10 ns;
  confirmar <= '0'; wait for 30 ns;
  operacao <= "11";
  confirmar <= '1'; wait for 10 ns;
  confirmar <= '0'; wait for 30 ns;
  operacao <= "10";
  confirmar <= '1'; wait for 10 ns;
  confirmar <= '0'; wait for 30 ns;
  operacao <= "10";
  confirmar <= '1'; wait for 10 ns;
  confirmar <= '0'; wait for 30 ns;
  operacao <= "10";
  confirmar <= '1'; wait for 10 ns;
  confirmar <= '0'; wait for 30 ns;
  -- 330 ns: INIT, cifrado 002.
  modo_decifrar <= '1';
  confirmar <= '1'; wait for 10 ns;
  confirmar <= '0'; wait for 30 ns;
  operacao <= "10";
  confirmar <= '1'; wait for 10 ns;
  confirmar <= '0'; wait for 30 ns;
  switches <= std_logic_vector(to_unsigned(0, 10));
  confirmar <= '1'; wait for 10 ns;
  confirmar <= '0'; wait for 30 ns;
  operacao <= "10";
  confirmar <= '1'; wait for 10 ns;
  confirmar <= '0'; wait for 30 ns;
  switches <= std_logic_vector(to_unsigned(0, 10));
  confirmar <= '1'; wait for 10 ns;
  confirmar <= '0'; wait for 30 ns;
  operacao <= "10";
  confirmar <= '1'; wait for 10 ns;
  confirmar <= '0'; wait for 30 ns;
  switches <= std_logic_vector(to_unsigned(0, 10));
  confirmar <= '1'; wait for 10 ns;
  confirmar <= '0'; wait for 30 ns;
  -- 610 ns: RESULTADO, valor 002 e LED apagado.
  confirmar <= '1'; wait for 10 ns;
  confirmar <= '0'; wait for 30 ns;
  operacao <= "10";
  confirmar <= '1'; wait for 10 ns;
  confirmar <= '0'; wait for 30 ns;
  switches <= std_logic_vector(to_unsigned(3, 10));
  confirmar <= '1'; wait for 10 ns;
  confirmar <= '0'; wait for 30 ns;
  operacao <= "10";
  confirmar <= '1'; wait for 10 ns;
  confirmar <= '0'; wait for 30 ns;
  switches <= std_logic_vector(to_unsigned(3, 10));
  confirmar <= '1'; wait for 10 ns;
  confirmar <= '0'; wait for 30 ns;
  operacao <= "10";
  confirmar <= '1'; wait for 10 ns;
  confirmar <= '0'; wait for 30 ns;
  switches <= std_logic_vector(to_unsigned(3, 10));
  confirmar <= '1'; wait for 10 ns;
  confirmar <= '0'; wait for 30 ns;
  -- 890 ns: RESULTADO, valor 001 e LED aceso.
  reset <= '1'; wait for 10 ns; reset <= '0';
  wait;
 end process;
end architecture;

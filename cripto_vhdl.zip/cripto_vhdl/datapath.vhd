library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
entity datapath is
 port(clk, reset : in std_logic;
      switches : in std_logic_vector(9 downto 0);
      ld_v, ld_k, ld_x, ld_c, rot_mode, clr_n, inc_n, ld_acerto, clr_acerto, set_valido, clr_valido, sel_saida : in std_logic;
      sel_x : in std_logic_vector(2 downto 0);
      fim_camadas, cifrado_valido, acerto : out std_logic;
      valor_saida : out std_logic_vector(9 downto 0));
end entity;
architecture rtl of datapath is
 signal v, k, x, c, prox_x, r_xor, r_rot, r_perm : std_logic_vector(9 downto 0);
 signal n, n_mais_um, prox_n : std_logic_vector(1 downto 0);
 signal igual : std_logic;
begin
 rv: entity work.registrador port map(clk, reset, ld_v, switches, v);
 rk: entity work.registrador port map(clk, reset, ld_k, switches, k);
 rx: entity work.registrador port map(clk, reset, ld_x, prox_x, x);
 rc: entity work.registrador port map(clk, reset, ld_c, x, c);
 ox: entity work.XOR_cripto port map(x, k, r_xor);
 ro: entity work.roller port map(rot_mode, x, r_rot);
 pe: entity work.permuter port map(x, r_perm);
 cv: entity work.comparador port map(x, v, igual);
 ad: entity work.incrementador port map(n, n_mais_um);
 rn: entity work.registrador generic map(2)
     port map(clk, reset, clr_n or inc_n, prox_n, n);
 cn: entity work.comparador generic map(2) port map(n, "11", fim_camadas);
 prox_n <= "00" when clr_n = '1' else n_mais_um;

 with sel_x select prox_x <= switches when "000", r_xor when "001",
      r_rot when "010", r_perm when "011", c when "100", x when others;
 valor_saida <= c when sel_saida = '1' else x;

 process(clk)
 begin
  if rising_edge(clk) then
   if reset = '1' or clr_valido = '1' then cifrado_valido <= '0';
   elsif set_valido = '1' then cifrado_valido <= '1';
   end if;
   if reset = '1' or clr_acerto = '1' then acerto <= '0';
   elsif ld_acerto = '1' then acerto <= igual;
   end if;
  end if;
 end process;
end architecture;
